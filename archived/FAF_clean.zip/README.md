# Mon Projet FAF

## Installation

```bash
npm install
npm start

frontend/ : pages HTML, CSS et JS
backend/ : serveur Express